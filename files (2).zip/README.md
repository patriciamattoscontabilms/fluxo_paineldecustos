# Painel de Custos e Aderência de Programas Governamentais

Protótipo de painel analítico que integra **planejamento (PPA)**, **execução orçamentária** e **contratos**, usando inteligência artificial para dois cruzamentos:

1. **Custo do programa** — meta física confrontada com o valor liquidado
2. **Aderência contratual** — objeto do contrato confrontado com a finalidade do programa

> ⚠️ **Dados demonstrativos.** Os programas, ações, contratos e pareceres presentes nos arquivos HTML são fictícios, escritos apenas para ilustrar o formato das telas e das saídas. Nenhum dado real de órgão público foi utilizado.

---

## As quatro fases

| Fase | O que faz | Saída |
|---|---|---|
| **1 — Planejamento** | Percorre PPA → Programa → Ação e extrai a meta física e a meta financeira | Base estruturada do que foi prometido |
| **2 — Execução** | Extrai empenho, liquidação e pagamento; a liquidação é o marco do custo | Despesa reconhecida por ação e período |
| **3 — Custo (IA)** | Concilia meta física com valor liquidado | Custo do programa, custo unitário e desvio |
| **4 — Aderência (IA)** | Compara objeto contratado com finalidade do programa | Classificação, justificativa e nível de confiança |

**Por que a liquidação:** o empenho é apenas reserva de dotação e pode ser cancelado; o pagamento chega defasado em relação ao fato gerador. A liquidação é o estágio em que a despesa é reconhecida após a verificação do cumprimento da obrigação pelo credor.

**Meta física × meta financeira:** a meta física é a quantidade prometida (km, unidades, atendimentos) e serve de denominador do custo unitário. A meta financeira é a dotação prevista em reais. As duas são extraídas da ação.

---

## Conteúdo

```
.
├── index.html                          página inicial com acesso aos dois painéis
├── painel-ppa-execucao-contratos.html  painel com as quatro fases e dados demonstrativos
├── mapa-do-fluxo.html                  detalhamento etapa a etapa do fluxo de dados
└── docs/
    ├── Proposta_Solucao_...docx        documento da solução proposta
    └── Apresentacao_...pptx            apresentação de 12 slides, sem dados
```

Os arquivos HTML são autocontidos: um único arquivo cada, sem dependências além das fontes carregadas via Google Fonts. Basta abrir no navegador.

### mapa-do-fluxo.html

Detalha as 11 etapas do fluxo — 74 campos, 35 regras de tratamento e 22 pontos de exceção mapeados. Para cada etapa: origem do dado, periodicidade de carga, responsável, chave de ligação, campos extraídos, regras e o que fazer quando o dado falha.

---

## Como visualizar

Abrindo o arquivo direto no navegador, ou servindo localmente:

```bash
python3 -m http.server 8000
# depois acesse http://localhost:8000
```

Para publicar via GitHub Pages: **Settings → Pages → Source: branch `main`, pasta `/ (root)`**. O `index.html` na raiz vira a página inicial.

---

## Estado do projeto

Isto é um **protótipo navegável**, não um sistema em produção. Não há backend, banco de dados, autenticação nem integração com sistemas de origem, e a análise de IA está representada por textos de exemplo que ilustram o formato da saída.

O caminho para a versão operacional está descrito no documento em `docs/`: ingestão, armazenamento bruto, tratamento, inteligência, consumo e apresentação.

## Próximos passos

- [ ] Definir os programas do piloto, de alta materialidade e com meta física bem definida
- [ ] Levantar a forma de acesso a cada base: integração, exportação periódica ou carga manual
- [ ] Definir o valor de corte para revisão humana obrigatória na análise de aderência
- [ ] Designar os responsáveis por programa que validarão os resultados
- [ ] Confirmar campos e regras do `mapa-do-fluxo.html` junto aos gestores de cada base
